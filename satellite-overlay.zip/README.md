# 🛰 Satellite Overlay — Subway Builder Mod v4

Real-world satellite imagery overlaid on the game map via MapTiler.

## Setup (one time)

### 1. Install Node.js if needed
```bash
node --version   # should print v18 or higher
```
If not installed: https://nodejs.org (LTS version)

### 2. Install the mod
Copy the `satellite-overlay` folder into your mods directory:
```
~/Library/Application Support/metro-maker4/mods/satellite-overlay-final/
```
Enable it in **Settings → Mods**.

### 3. Start the proxy before playing
Open Terminal and run:
```bash
node "/Users/username/Library/Application Support/metro-maker4/mods/satellite-overlay-final/proxy.js"
```

You should see:
```
🛰  Satellite tile proxy running

   Tiles:    http://localhost:8080/tile/{z}/{x}/{y}.jpg
   TileJSON: http://localhost:8080/tiles.json
   Health:   http://localhost:8080/health
```

Verify it works by opening http://localhost:8080/health in your browser — should say `ok`.

**Leave this terminal open while playing. Press Ctrl+C to stop.**

### 4. Load a city

The satellite layer appears automatically. Click the **Satellite** button in the toolbar to open the panel (toggle on/off, adjust opacity).

---

## Why the proxy?

The game uses a Content Security Policy (CSP) that blocks direct connections to `api.maptiler.com`. The proxy runs on `localhost` which is always allowed, and forwards tile requests to MapTiler on your behalf.

```
Game → localhost:8080 → MapTiler → tiles back to game
```

## Tile source

Using MapTiler Satellite v4, 256px tiles:
```
https://api.maptiler.com/maps/satellite-v4/tiles.json?key=...
```

Attribution: © MapTiler © OpenStreetMap contributors
