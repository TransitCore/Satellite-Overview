/**
 * Satellite Tile Proxy
 * ====================
 * Run ONCE before launching Subway Builder:
 *
 *   node proxy.js
 *
 * Leave this terminal open while playing.
 * No npm install needed — uses only Node.js built-ins.
 *
 * What it does:
 *   The game blocks external domains (api.maptiler.com) via CSP.
 *   This proxy sits on 127.0.0.1:8080 — which the game allows —
 *   and forwards tile requests to MapTiler on your behalf.
 *
 *   Game → 127.0.0.1:8080 → MapTiler → back
 *
 * Disk cache:
 *   Fetched tiles are saved to ./tile-cache/{z}/{x}/{y}.jpg next to this file.
 *   On repeat requests the tile is served from disk — no network call needed.
 *   The cache persists across restarts. Delete the tile-cache/ folder to reset it.
 */

const http  = require('http');
const https = require('https');
const fs    = require('fs');
const path  = require('path');

// ── Config ─────────────────────────────────────────────────────────────────────
// Paste your MapTiler API key here.
// Get one free at: https://cloud.maptiler.com/account/keys/
const KEY  = 'YOURKEYHERE';
const PORT = 8080;

// Tile cache lives next to this script
const CACHE_DIR = path.join(__dirname, 'tile-cache');

// ── Helpers ────────────────────────────────────────────────────────────────────
const tileUrl = (z, x, y) =>
    `https://api.maptiler.com/maps/satellite-v4/256/${z}/${x}/${y}.jpg?key=${KEY}`;

const cachePath = (z, x, y) =>
    path.join(CACHE_DIR, String(z), String(x), `${y}.jpg`);

// Ensure the cache directory structure exists
function ensureCacheDir(z, x) {
    const dir = path.join(CACHE_DIR, String(z), String(x));
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

// Count cached tiles on startup
function countCachedTiles() {
    if (!fs.existsSync(CACHE_DIR)) return 0;
    let count = 0;
    const zDirs = fs.readdirSync(CACHE_DIR);
    for (const z of zDirs) {
        const zPath = path.join(CACHE_DIR, z);
        if (!fs.statSync(zPath).isDirectory()) continue;
        for (const x of fs.readdirSync(zPath)) {
            const xPath = path.join(zPath, x);
            if (!fs.statSync(xPath).isDirectory()) continue;
            count += fs.readdirSync(xPath).length;
        }
    }
    return count;
}

// ── Server ─────────────────────────────────────────────────────────────────────
let hits = 0;
let misses = 0;

http.createServer((req, res) => {

    // CORS — allow the game's webview
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    // Health check — also reports cache stats
    if (req.url === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            status: 'ok',
            cache:  { hits, misses, total: hits + misses },
        }));
        return;
    }

    // TileJSON
    if (req.url === '/tiles.json') {
        const tileJson = {
            tilejson:    '2.2.0',
            name:        'Satellite',
            description: 'MapTiler Satellite v4',
            version:     '1.0.0',
            attribution: '© <a href="https://www.maptiler.com/copyright/">MapTiler</a> © <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            scheme:      'xyz',
            tiles:       [`http://127.0.0.1:${PORT}/tile/{z}/{x}/{y}.jpg`],
            minzoom:     0,
            maxzoom:     20,
            bounds:      [-180, -85.051129, 180, 85.051129],
        };
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(tileJson));
        return;
    }

    // Tile requests: /tile/{z}/{x}/{y}.jpg
    const match = req.url.match(/^\/tile\/(\d+)\/(\d+)\/(\d+)\.jpg/);
    if (!match) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Not found');
        return;
    }

    const [, z, x, y] = match;
    const cached = cachePath(z, x, y);

    // ── Serve from cache if available ──────────────────────────────────────────
    if (fs.existsSync(cached)) {
        hits++;
        const data = fs.readFileSync(cached);
        res.writeHead(200, {
            'Content-Type':  'image/jpeg',
            'Content-Length': data.length,
            'Cache-Control': 'public, max-age=604800', // 7 days
            'X-Cache':       'HIT',
            'Access-Control-Allow-Origin': '*',
        });
        res.end(data);
        return;
    }

    // ── Fetch from MapTiler and cache ──────────────────────────────────────────
    misses++;
    const upstream = tileUrl(z, x, y);

    https.get(upstream, (upRes) => {
        if (upRes.statusCode !== 200) {
            // Don't cache errors
            res.writeHead(upRes.statusCode, { 'Content-Type': 'text/plain' });
            res.end(`Upstream returned ${upRes.statusCode}`);
            upRes.resume();
            return;
        }

        const chunks = [];
        upRes.on('data', chunk => chunks.push(chunk));
        upRes.on('end', () => {
            const buf = Buffer.concat(chunks);

            // Write to disk cache (async, non-blocking)
            try {
                ensureCacheDir(z, x);
                fs.writeFileSync(cached, buf);
            } catch (e) {
                console.warn(`[proxy] Cache write failed for ${z}/${x}/${y}:`, e.message);
            }

            res.writeHead(200, {
                'Content-Type':   'image/jpeg',
                'Content-Length': buf.length,
                'Cache-Control':  'public, max-age=604800',
                'X-Cache':        'MISS',
                'Access-Control-Allow-Origin': '*',
            });
            res.end(buf);
        });
    }).on('error', (err) => {
        console.error(`[proxy] Upstream error for ${z}/${x}/${y}:`, err.message);
        res.writeHead(502, { 'Content-Type': 'text/plain' });
        res.end('Bad gateway');
    });

}).listen(PORT, '127.0.0.1', () => {
    const cached = countCachedTiles();
    console.log('\n🛰  Satellite tile proxy running');
    console.log(`\n   Tiles:    http://127.0.0.1:${PORT}/tile/{z}/{x}/{y}.jpg`);
    console.log(`   TileJSON: http://127.0.0.1:${PORT}/tiles.json`);
    console.log(`   Health:   http://127.0.0.1:${PORT}/health`);
    console.log(`\n   📦 Disk cache: ${CACHE_DIR}`);
    console.log(`      ${cached} tiles already cached`);
    console.log('\n   ✓ Leave this terminal open while playing.');
    console.log('   ✓ Press Ctrl+C to stop.\n');
});
