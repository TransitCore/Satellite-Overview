/**
 * Satellite Overlay Mod v4
 * ========================
 * Overlays MapTiler satellite imagery on the game map.
 *
 * REQUIRES: proxy.js running before launching the game.
 *   node proxy.js   (in a terminal, leave open while playing)
 *
 * Architecture:
 *   - Satellite is placed directly above 'background' — the lowest and most
 *     stable layer. This is immune to the construction tab style-reload bug
 *     where reapplyCustomMapLayers was pushing satellite above game elements.
 *   - All city decoration layers (buildings, water, parks, roads, etc.) sit
 *     above satellite and can be individually toggled off via the panel.
 *   - Game elements (station-collision-big/small, arrows-layer) are always
 *     on top regardless — they are added by the game engine after custom layers.
 *
 * Layer order (confirmed from in-game console):
 *   background → [sat-overlay] → buildings-3d → water → parks-large →
 *   parks-small → airports → general-tiles → ocean-depth-labels →
 *   neighborhood-labels → suburb-labels → city-labels → intersections-layer →
 *   road-labels → station-collision-big → station-collision-small → arrows-layer
 */
(function () {
    'use strict';

    if (!window.SubwayBuilderAPI) {
        console.error('[SatelliteOverlay] SubwayBuilderAPI not found.');
        return;
    }

    const api = window.SubwayBuilderAPI;
    const { React, components } = api.utils;
    const h = React.createElement;
    const { Switch, Slider } = components;

    // ── Constants ──────────────────────────────────────────────────────────────
    const SOURCE_ID  = 'sat-overlay-source';
    const LAYER_ID   = 'sat-overlay-layer';
    const PROXY_PORT = 8080;

    const TILE_URL = `http://127.0.0.1:${PROXY_PORT}/tile/{z}/{x}/{y}.jpg`;

    // All city decoration layers above satellite, grouped for the UI.
    // Toggle any of these off to reveal the satellite beneath.
    const CITY_LAYER_GROUPS = [
        { key: 'buildings',    label: '🏢 Buildings',    layers: ['buildings-3d'] },
        { key: 'water',        label: '🌊 Water',        layers: ['water'] },
        { key: 'parks',        label: '🌳 Parks',        layers: ['parks-large', 'parks-small'] },
        { key: 'general',      label: '🗺 General Tiles', layers: ['general-tiles'] },
        { key: 'roads',        label: '🛣 Roads',        layers: ['road-labels', 'intersections-layer'] },
        { key: 'airports',     label: '✈️ Airports',     layers: ['airports'] },
    ];

    // ── Persistent state ───────────────────────────────────────────────────────
    const defaultCityLayers = Object.fromEntries(CITY_LAYER_GROUPS.map(g => [g.key, false]));
    const defaults = { enabled: true, opacity: 1.0, cityLayers: { ...defaultCityLayers } };
    let state = { ...defaults, cityLayers: { ...defaultCityLayers } };
    let mapInst    = null;
    let layerAdded = false;
    let _setUi     = null;

    // ── Storage ────────────────────────────────────────────────────────────────
    async function loadState() {
        try {
            const saved = await api.storage.get('v4', {});
            state = {
                ...defaults,
                ...saved,
                cityLayers: { ...defaultCityLayers, ...(saved.cityLayers || {}) },
            };
        } catch (_) {}
    }

    function saveState() {
        api.storage.set('v4', {
            enabled:    state.enabled,
            opacity:    state.opacity,
            cityLayers: state.cityLayers,
        }).catch(() => {});
    }

    // ── City layer visibility ──────────────────────────────────────────────────
    function applyCityLayerVisibility() {
        try {
            const map = api.utils.getMap();
            if (!map) return;
            for (const group of CITY_LAYER_GROUPS) {
                const visible = state.cityLayers[group.key];
                for (const layerId of group.layers) {
                    try {
                        map.setLayoutProperty(layerId, 'visibility', visible ? 'visible' : 'none');
                    } catch (_) {
                        // Layer may not exist in this city — skip silently
                    }
                }
            }
        } catch (_) {}
    }

    // ── Map layer ──────────────────────────────────────────────────────────────

    /**
     * Satellite is placed immediately above 'background' — the very first layer
     * in the stack and always present, even during style reloads triggered by
     * the construction tab. This means the satellite can never end up above
     * game elements (stations, tracks, arrows) which are added later.
     */
    function addLayer() {
        if (!mapInst) return;
        try {
            api.map.registerSource(SOURCE_ID, {
                type:        'raster',
                tiles:       [TILE_URL],
                tileSize:    256,
                minzoom:     0,
                maxzoom:     20,
                attribution: '© <a href="https://www.maptiler.com/copyright/">MapTiler</a> © <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>',
            });

            api.map.registerLayer({
                id:     LAYER_ID,
                type:   'raster',
                source: SOURCE_ID,
                layout: {
                    visibility: state.enabled ? 'visible' : 'none',
                },
                paint: {
                    'raster-opacity':            state.opacity,
                    'raster-opacity-transition': { duration: 300, delay: 0 },
                },
            }, 'buildings-3d'); // just above background — below all city decoration

            layerAdded = true;
            applyCityLayerVisibility();
            console.log(`[SatelliteOverlay] Layer added — opacity: ${state.opacity}`);
        } catch (err) {
            console.error('[SatelliteOverlay] addLayer error:', err);
        }
    }

    function syncLayer() {
        if (!layerAdded) { addLayer(); return; }
        try {
            const map = api.utils.getMap();
            if (!map) return;
            map.setLayoutProperty(LAYER_ID, 'visibility', state.enabled ? 'visible' : 'none');
            map.setPaintProperty(LAYER_ID, 'raster-opacity', state.opacity);
        } catch (_) {
            layerAdded = false;
            addLayer();
        }
    }

    // ── UI ─────────────────────────────────────────────────────────────────────
    function Panel() {
        const [ui, setUi] = React.useState({
            enabled:    state.enabled,
            opacity:    state.opacity,
            cityLayers: { ...state.cityLayers },
        });

        React.useEffect(() => {
            _setUi = (patch) => setUi(s => ({ ...s, ...patch }));
            return () => { _setUi = null; };
        }, []);

        const [center, setCenter] = React.useState(null);
        React.useEffect(() => {
            try {
                const map = api.utils.getMap();
                if (map) {
                    const c = map.getCenter();
                    setCenter({ lat: c.lat.toFixed(4), lng: c.lng.toFixed(4) });
                }
            } catch (_) {}
        }, []);

        function update(patch) {
            Object.assign(state, patch);
            setUi(s => ({ ...s, ...patch }));
            syncLayer();
            saveState();
        }

        function updateCityLayer(key, visible) {
            const cityLayers = { ...state.cityLayers, [key]: visible };
            state.cityLayers = cityLayers;
            setUi(s => ({ ...s, cityLayers }));
            applyCityLayerVisibility();
            saveState();
        }

        function resetCityLayers() {
            const cityLayers = { ...defaultCityLayers };
            state.cityLayers = cityLayers;
            setUi(s => ({ ...s, cityLayers }));
            applyCityLayerVisibility();
            saveState();
        }

        const allVisible = CITY_LAYER_GROUPS.every(g => ui.cityLayers[g.key]);

        const S = {
            root:       { display: 'flex', flexDirection: 'column', gap: '14px', padding: '2px 0' },
            row:        { display: 'flex', alignItems: 'center', justifyContent: 'space-between' },
            hr:         { border: 'none', borderTop: '1px solid #1f2937', margin: 0 },
            label:      { fontSize: '10px', fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.07em' },
            title:      { fontSize: '13px', fontWeight: 500, color: '#e5e7eb' },
            sub:        { fontSize: '11px', color: '#9ca3af' },
            pct:        { fontSize: '12px', fontWeight: 700, color: '#60a5fa' },
            info:       { background: 'rgba(0,0,0,0.3)', borderRadius: '6px', padding: '9px 11px', fontSize: '11px', color: '#9ca3af', fontFamily: 'monospace', lineHeight: 1.7 },
            muted:      { color: '#4b5563' },
            groupLabel: { fontSize: '12px', color: '#d1d5db' },
            resetBtn:   { fontSize: '10px', color: '#6b7280', background: 'none', border: 'none', cursor: 'pointer', padding: 0, textDecoration: 'underline' },
        };

        return h('div', { style: S.root },

            // ── Satellite toggle ───────────────────────────────────────────
            h('div', { style: S.row },
                h('div', null,
                    h('div', { style: S.title }, '🛰 Satellite Overlay'),
                    h('div', { style: S.sub }, ui.enabled ? '● Visible' : '○ Hidden'),
                ),
                h(Switch, {
                    checked:         ui.enabled,
                    onCheckedChange: v => update({ enabled: v }),
                }),
            ),

            h('hr', { style: S.hr }),

            // ── Opacity slider ─────────────────────────────────────────────
            h('div', null,
                h('div', { style: { ...S.row, marginBottom: '10px' } },
                    h('span', { style: S.label }, 'Opacity'),
                    h('span', { style: S.pct }, `${Math.round(ui.opacity * 100)}%`),
                ),
                h(Slider, {
                    min:           0,
                    max:           1,
                    step:          0.05,
                    value:         [ui.opacity],
                    disabled:      !ui.enabled,
                    onValueChange: val => update({ opacity: Array.isArray(val) ? val[0] : val }),
                }),
            ),

            h('hr', { style: S.hr }),

            // ── City layer toggles ─────────────────────────────────────────
            h('div', null,
                h('div', { style: { ...S.row, marginBottom: '10px' } },
                    h('span', { style: S.label }, 'Map Layers'),
                    !allVisible && h('button', { style: S.resetBtn, onClick: resetCityLayers }, 'Reset all'),
                ),
                h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px' } },
                    ...CITY_LAYER_GROUPS.map(group =>
                        h('div', { key: group.key, style: S.row },
                            h('span', { style: S.groupLabel }, group.label),
                            h(Switch, {
                                checked:         ui.cityLayers[group.key],
                                onCheckedChange: v => updateCityLayer(group.key, v),
                            }),
                        )
                    ),
                ),
            ),

            h('hr', { style: S.hr }),

            // ── Status info ────────────────────────────────────────────────
            h('div', { style: S.info },
                h('div', null,
                    h('span', { style: S.muted }, 'source   '),
                    'MapTiler satellite-v4',
                ),
                h('div', null,
                    h('span', { style: S.muted }, 'proxy    '),
                    `localhost:${PROXY_PORT}`,
                ),
                center && h('div', null,
                    h('span', { style: S.muted }, 'center   '),
                    `${center.lat}°, ${center.lng}°`,
                ),
            ),

            h('div', { style: { fontSize: '10px', color: '#6b7280', lineHeight: 1.5 } },
                'Proxy must be running: ',
                h('code', { style: { color: '#9ca3af' } }, 'node proxy.js'),
            ),
        );
    }

    // ── Init ───────────────────────────────────────────────────────────────────
    async function init(map) {
        mapInst = map;
        await loadState();

        try {
            const c = map.getCenter();
            console.log(`[SatelliteOverlay] City center: ${c.lat.toFixed(5)}, ${c.lng.toFixed(5)}`);
        } catch (_) {}

        addLayer();

        api.ui.addToolbarPanel({
            id:      'sat-panel',
            icon:    'Satellite',
            tooltip: 'Satellite Overlay',
            title:   'Satellite Overlay',
            width:   260,
            render:  () => h(Panel),
        });

        console.log('[SatelliteOverlay] v4 ready ✓');
        api.ui.showNotification('🛰 Satellite Overlay active', 'success');
    }

    api.hooks.onMapReady(map => {
        init(map).catch(err => console.error('[SatelliteOverlay] init error:', err));
    });

})();
